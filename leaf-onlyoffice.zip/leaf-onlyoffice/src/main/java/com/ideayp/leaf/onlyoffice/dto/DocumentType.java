package com.ideayp.leaf.onlyoffice.dto;

/**
 * 文件类型
 *
 * @author 95765
 */
public enum DocumentType {
    Text,
    Spreadsheet,
    Presentation
}