package com.ideayp.leaf.onlyoffice.constants;

/**
 * 常量类
 * <p>email: ypasdf@163.com</p>
 * <p>Copyright: Copyright (c) 2018</p>
 * <P>Date: 2018/12/14 </P>
 *
 * @author leaf
 * @version 1.0
 */
public class Constant {

    public static final String DOC_API_URL = "/web-apps/apps/api/documents/api.js";
}
